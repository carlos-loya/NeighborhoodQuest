//
//  PushButtonView.swift
//  Neighborhood Quest
//
//  Created by Kyle Kimery on 11/21/16.
//  Copyright © 2016 Kenneth James. All rights reserved.
//

import UIKit

class PushButtonView: UIButton {

    override func drawRect(rect: CGRect) {
        var path = UIBezierPath(ovalInRect: rect)
        UIColor.blueColor().setFill()
        path.fill()
    }

}
