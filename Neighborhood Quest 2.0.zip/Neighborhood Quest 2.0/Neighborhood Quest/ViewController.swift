//
//  ViewController.swift
//  Neighborhood Quest
//
//  Created by Kenneth James on 11/18/16.
//  Copyright © 2016 Kenneth James. All rights reserved.
//

import UIKit

import MapKit

class ViewController: UIViewController {

    @IBOutlet var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib
        
        let initialLocation = CLLocation(latitude: 30.2747, longitude: -97.7404)
        
        centerMapOnLocation(initialLocation)
        
        mapView.delegate = self
        // show artwork on map
        let artwork = Artwork(title: "Austin Capitol",
                              locationName: "Downtown",
                              discipline: "Building",
                              coordinate: CLLocationCoordinate2D(latitude: 30.2747, longitude: -97.7404))
        
        mapView.addAnnotation(artwork)
        
    }
    
    

    let regionRadius: CLLocationDistance = 1000
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    


}

