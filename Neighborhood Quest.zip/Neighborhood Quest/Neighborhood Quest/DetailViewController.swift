//
//  DetailViewController.swift
//  Neighborhood Quest
//
//  Created by Kenneth James on 11/18/16.
//  Copyright © 2016 Kenneth James. All rights reserved.
//
import UIKit
import Foundation

class DetailViewController: UIViewController {
    
    
    
}
