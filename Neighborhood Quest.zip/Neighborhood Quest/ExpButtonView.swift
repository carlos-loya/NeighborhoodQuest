//
//  ExpButtonView.swift
//  Neighborhood Quest
//
//  Created by Kyle Kimery on 11/28/16.
//  Copyright © 2016 Kenneth James. All rights reserved.
//

import UIKit
import CoreData


class ExpButtonView: UIButton {

    var statsArray = [NSManagedObject]()

    override func drawRect(rect: CGRect) {
        var path = UIBezierPath(rect: rect)
        UIColor.greenColor().setFill()
        path.fill()
        
        var newPath = UIBezierPath()
        newPath.lineWidth = 30.0
        newPath.moveToPoint(CGPoint(x: 0, y: 0))
        
        
        let appDelegate =
            UIApplication.sharedApplication().delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        let fetchRequest = NSFetchRequest(entityName: "Stats")
        
        do {
            let results =
                try managedContext.executeFetchRequest(fetchRequest)
            statsArray = results as! [NSManagedObject]
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
        var quizzes = Int(statsArray[0].valueForKey("numQuizzes") as! String)
        var numCorrect = Int(statsArray[0].valueForKey("numCorrect") as! String)
        
        var percent = Double(numCorrect!)/Double(quizzes!)
        
        newPath.addLineToPoint(CGPoint(x: percent*400, y: 30))
        UIColor.blueColor().setStroke()
        newPath.stroke()
        
        
    }

}
